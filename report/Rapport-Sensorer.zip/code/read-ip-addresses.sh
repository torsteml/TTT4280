#!/bin/bash
num_times=$(seq 0 10)
for i in $num_times; do
        wlan_ip=$(ifconfig wlan0 | sed -rn 's/.*inet [addr:]*([0-9|.]+).*/\1/p' | sed -rn 's/./\0 /gp')
        eth_ip=$(ifconfig eth0 | sed -rn 's/.*inet [addr:]*([0-9|.]+).*/\1/p' | sed -rn 's/./\0 /gp')
        espeak "wifi-address. $wlan_ip" --stdout | aplay
        espeak "cable-address. $eth_ip" --stdout | aplay
done